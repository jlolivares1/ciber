<?php

	$lang = "en";
	switch($lang) {
	
		case "en":
			include ("lang/en.php");
			break;
		default:
			include ("lang/en.php");
			break;
	}

?>
