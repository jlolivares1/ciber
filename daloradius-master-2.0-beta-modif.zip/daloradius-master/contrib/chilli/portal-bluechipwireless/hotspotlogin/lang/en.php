<?php
# daloRADIUS edition - fixed up variable definition through-out the code
# as well as parted the code for the sake of modularity and ability to 
# to support templates and languages easier.
# Copyright (C) Enginx and Liran Tal 2007, 2008

$ChilliSpot="BluechipWiFi Hotspot";
$title="$ChilliSpot Login";
$centerUsername="Username";
$centerPassword="Password";
$centerLogin="Login";
$centerPleasewait="Please wait.......";
$centerLogout="Logout";
$h1Login="$ChilliSpot Login";
$h1Failed="$ChilliSpot Login Failed";  
$h1Loggedin="Logged in to $ChilliSpot";
$h1Loggingin="Logging in to $ChilliSpot";
$h1Loggedout="Logged out from $ChilliSpot";
$centerdaemon="Login must be performed through $ChilliSpot server";
$centerencrypted="Login must use encrypted connection";


?>
